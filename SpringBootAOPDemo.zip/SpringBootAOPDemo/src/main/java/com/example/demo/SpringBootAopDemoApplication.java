package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

import com.example.demo.model.Employee;
import com.example.demo.model.Student;
import com.example.demo.service.EmployeeService;
import com.example.demo.service.StudentService;

@SpringBootApplication
@EnableAspectJAutoProxy
public class SpringBootAopDemoApplication {

	public static void main(String[] args) {
		ApplicationContext applicationContext = SpringApplication.run(SpringBootAopDemoApplication.class, args);
		System.out.println("*************Employee Service************");
		EmployeeService employeeService = applicationContext.getBean(EmployeeService.class);
		employeeService.addEmployee(new Employee(100L, "suresh", "kumar", "suresh@gmail.com"));
		try {
			System.out.println(employeeService.getEmployeeById(100L));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(employeeService.getAllEmployees());
		System.out.println("*********Student Service**********");
		StudentService studentService = applicationContext.getBean(StudentService.class);
		studentService.addStudent(new Student(111, "suresh", 560));
		System.out.println(studentService.getStudentById(111l));
		System.out.println(studentService.getAllStudents());

	}

}
