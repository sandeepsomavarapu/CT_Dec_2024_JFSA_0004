package com.example.demo.repo;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.entity.Student;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

@Repository
public class StudentRepoImpl implements StudentRepository {
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public void save(Student student) {
		entityManager.persist(student);
	}

	@Override
	public List<Student> getAll() {

		return entityManager.createQuery("select s from Student s", Student.class).getResultList();
	}

	@Override
	public Student getById(Integer id) {

		return entityManager.find(Student.class, id);
	}

	@Override
	public void delete(Student student) {
		entityManager.remove(student);
	}

}
