package com.example.demo.repo;

import java.util.List;

import com.example.demo.entity.Student;

public interface StudentRepository {
	void save(Student student);

	List<Student> getAll();

	Student getById(Integer id);

	void delete(Student student);
}
