package com.example.demo.repo;

import java.util.List;

import com.example.demo.entity.Student;
import com.example.demo.exceptions.StudentNotFound;

public interface StudentRepository {
	void save(Student student);

	List<Student> getAll();

	Student getById(Integer id) throws StudentNotFound;

	void delete(Student student);
}
