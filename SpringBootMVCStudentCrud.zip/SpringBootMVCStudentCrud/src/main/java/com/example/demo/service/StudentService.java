package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Student;
import com.example.demo.exceptions.StudentNotFound;

public interface StudentService {
	void save(Student student) throws StudentNotFound;

	List<Student> getAll();

	Student getById(Integer id) throws StudentNotFound;

	void delete(Student student);
}