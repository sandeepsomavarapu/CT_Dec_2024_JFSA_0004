package com.example.demo.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.controller.StudentController;
import com.example.demo.entity.Student;
import com.example.demo.exceptions.StudentNotFound;
import com.example.demo.repo.StudentRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class StudentServiceImpl implements StudentService {
	private static final Logger logger = LoggerFactory.getLogger(StudentServiceImpl.class);

	@Autowired
	StudentRepository studentRepository;

	@Override
	public void save(Student student) throws StudentNotFound {
		if (student.getId() == null) {
			studentRepository.save(student);
		} else {
			Student staffUpdate = studentRepository.getById(student.getId());
			staffUpdate.setName(student.getName());
			staffUpdate.setRollNo(student.getRollNo());
			staffUpdate.setEmailId(student.getEmailId());
			studentRepository.save(staffUpdate);
		}
	}

	@Override
	public List<Student> getAll() {
		logger.info("in  serivce");
		return studentRepository.getAll();
	}

	@Override
	public Student getById(Integer id) throws StudentNotFound {
		return studentRepository.getById(id);

	}

	@Override
	public void delete(Student student) {
		studentRepository.delete(student);
	}
}