package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRestJpaBankingAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRestJpaBankingAppApplication.class, args);
	}

}
