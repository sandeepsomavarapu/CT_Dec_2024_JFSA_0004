package com.example.demo.repository;

import com.example.demo.entity.Account;
import com.example.demo.exceptions.AccountNotFound;

public interface AccountRepository {
	public String createAccount(Account account);

	public Account updateAccount(Account account) throws AccountNotFound;

	public String closeAccount(int accountNo) throws AccountNotFound;

	public Account getAccountDetails(int accountNo) throws AccountNotFound;

}
