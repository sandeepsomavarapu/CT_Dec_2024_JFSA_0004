package com.example.demo.repository;

import org.springframework.stereotype.Repository;

import com.example.demo.entity.Account;
import com.example.demo.exceptions.AccountNotFound;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;

@Repository
@Transactional
public class AccountRepositoryImpl implements AccountRepository {
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public String createAccount(Account account) {
		entityManager.persist(account);
		return "Account Created Successfully";
	}

	@Override
	public Account updateAccount(Account account) throws AccountNotFound {
		return entityManager.merge(account);
	}

	@Override
	public String closeAccount(int accountNo) throws AccountNotFound {
		Account account = entityManager.find(Account.class, accountNo);
		if (account != null) {
			entityManager.remove(account);
			return "Account closed Successfully";
		} else
			throw new AccountNotFound("Enter Valid Account Number:");
	}

	@Override
	public Account getAccountDetails(int accountNo) throws AccountNotFound {
		Account account = entityManager.find(Account.class, accountNo);
		if (account != null) {
			return account;
		} else {
			throw new AccountNotFound("No Account Found With Given AccNo..");
		}
	}

}
