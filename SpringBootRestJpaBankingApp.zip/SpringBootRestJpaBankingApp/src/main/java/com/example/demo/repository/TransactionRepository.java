package com.example.demo.repository;

import java.util.List;

import com.example.demo.entity.Transaction;

public interface TransactionRepository {

	public String addTransaction(Transaction transaction);

	public Transaction getTransaction(int transactionId);

	public List<Transaction> getAllTransactions(int accountNum);

	public String deleteTransaction(int transactionId);

}
