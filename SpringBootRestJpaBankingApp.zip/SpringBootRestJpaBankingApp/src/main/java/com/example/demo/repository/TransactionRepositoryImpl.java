package com.example.demo.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.entity.Transaction;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import jakarta.transaction.Transactional;

@Repository
@Transactional
public class TransactionRepositoryImpl implements TransactionRepository {
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public String addTransaction(Transaction transaction) {
		entityManager.persist(transaction);
		return "Transaction Saved Successfully";
	}

	@Override
	public Transaction getTransaction(int transactionId) {

		return entityManager.find(Transaction.class, transactionId);
	}

	@Override
	public List<Transaction> getAllTransactions(int accountNum) {
		TypedQuery<Transaction> trans = entityManager
				.createQuery("select t from Transaction t where t.account.accNo=?1", Transaction.class);
		trans.setParameter(1, accountNum);
		return trans.getResultList();
	}

	@Override
	public String deleteTransaction(int transactionId) {
		entityManager.remove(getTransaction(transactionId));
		return "Transaction Deleted!!!";
	}

}
