package com.example.demo.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Account;
import com.example.demo.entity.Transaction;
import com.example.demo.exceptions.AccountNotFound;
import com.example.demo.exceptions.InsufficientBalance;
import com.example.demo.repository.AccountRepository;

@Service
public class AccountServiceImpl implements AccountService {
	@Autowired
	AccountRepository repo;
	@Autowired
	TransactionService transactionService;

	@Override
	public String createAccount(Account account) {

		return repo.createAccount(account);
	}

	@Override
	public Account updateAccount(Account account) throws AccountNotFound {

		return repo.updateAccount(account);
	}

	@Override
	public String closeAccount(int accountNo) throws AccountNotFound {

		return repo.closeAccount(accountNo);
	}

	@Override
	public Account getAccountDetails(int accountNo) throws AccountNotFound {

		return repo.getAccountDetails(accountNo);
	}

	@Override
	public double withdraw(int accNo, double amountToWithdraw) throws AccountNotFound, InsufficientBalance {
		Account account = getAccountDetails(accNo);
		double oldBalance = account.getAccBalance();
		if (oldBalance > amountToWithdraw) {
			double newBalance = oldBalance - amountToWithdraw;
			account.setAccBalance(newBalance);
			updateAccount(account);
			Transaction transaction=new Transaction();
			transaction.setAccount(account);
			transaction.setTimeOfTransaction(new Date());
			transaction.setTransactionType("withdraw");
			transaction.setUpdatedBalance(newBalance);
			transactionService.addTransaction(transaction);
			return newBalance;
		} else
			throw new InsufficientBalance("Insuffcient Balance To Withdraw...");
	}

	@Override
	public double deposit(int accNo, double amountToDeposit) throws AccountNotFound {
		Account account = getAccountDetails(accNo);
		double oldBalance = account.getAccBalance();
		double newBalance = oldBalance + amountToDeposit;
		account.setAccBalance(newBalance);
		updateAccount(account);
		return newBalance;
	}

	@Override
	public double fundTransfer(int fromAccNo, int toAccNo, double amountToTransfer)
			throws AccountNotFound, InsufficientBalance {
		double updatedBalnceFromAcc = withdraw(fromAccNo, amountToTransfer);
		deposit(toAccNo, amountToTransfer);
		return updatedBalnceFromAcc;
	}

}
