package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Transaction;

public interface TransactionService {
	public String addTransaction(Transaction transaction);

	public Transaction getTransaction(int transactionId);

	public List<Transaction> getAllTransactions(int accountNum);

	public String deleteTransaction(int transactionId);

}
