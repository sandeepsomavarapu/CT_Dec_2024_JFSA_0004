package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Transaction;
import com.example.demo.repository.TransactionRepository;

@Service
public class TransactionServiceImpl implements TransactionService {
	@Autowired
	TransactionRepository repo;
	@Override
	public String addTransaction(Transaction transaction) {
		return repo.addTransaction(transaction);
	}
	@Override
	public Transaction getTransaction(int transactionId) {
		return repo.getTransaction(transactionId);
	}
	@Override
	public List<Transaction> getAllTransactions(int accountNum) {
		return repo.getAllTransactions(accountNum);
	}
	@Override
	public String deleteTransaction(int transactionId) {
		return repo.deleteTransaction(transactionId);
	}
}
