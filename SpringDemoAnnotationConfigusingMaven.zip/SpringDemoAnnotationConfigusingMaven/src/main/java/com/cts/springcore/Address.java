package com.cts.springcore;

import org.springframework.stereotype.Component;

@Component
public class Address {
	private int hno;
	private String colony;
	private int pincode;

//	@Override
//	public String toString() {
//		return "Address [hno=" + hno + ", colony=" + colony + ", pincode=" + pincode + "]";
//	}

	public int getHno() {
		return hno;
	}

	public void setHno(int hno) {
		this.hno = hno;
	}

	public String getColony() {
		return colony;
	}

	public void setColony(String colony) {
		this.colony = colony;
	}

	public int getPincode() {
		return pincode;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
	}

	public Address() {
		System.out.println("Address Default Constructor");
	}

	public Address(int hno, String colony, int pincode) {
		super();
		this.hno = hno;
		this.colony = colony;
		this.pincode = pincode;
	}
	
}
