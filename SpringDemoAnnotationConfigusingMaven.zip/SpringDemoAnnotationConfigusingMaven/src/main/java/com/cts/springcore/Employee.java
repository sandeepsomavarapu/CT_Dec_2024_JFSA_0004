package com.cts.springcore;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("emp")
public class Employee {
	private int empid;
	private String empName;
	@Autowired
	private Address address;// has-a


//	@Override
//	public String toString() {
//		return "Employee [empid=" + empid + ", empName=" + empName + ", address=" + address + "]";
//	}

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Employee() {
		System.out.println("Default Constructor");
	}

	public Employee(int empid, String empName, Address address) {
		super();
		this.empid = empid;
		this.empName = empName;
		this.address = address;
	}
	

}
