package com.cts.springcore;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ClassPathXmlApplicationContext;
@Configuration
@ComponentScan("com.cts.springcore")
public class Test {

	public static void main(String[] args) {
//		Employee obj = new Employee(null);
//		Resource resource=new ClassPathResource("springconfig.xml");
//		BeanFactory factory=new XmlBeanFactory(resource);//ctrl+shift+o
		
		ApplicationContext context=new AnnotationConfigApplicationContext(Test.class);
	
		Employee employee=(Employee) context.getBean("emp");
			System.out.println(employee);
		
			System.out.println(employee.getAddress());
			
			
			
			
			
//		   
//		Employee employee1=(Employee) context.getBean("emp");
//			System.out.println(employee1);
	}//BeanFactory->lazy initializer,ApplicationContext-->eager initializer

}//spring-->dependency injection
